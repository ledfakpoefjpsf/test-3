package nova.client.client.module;

// @name: ModuleManager
// @type: Client Module Registry
// @location: src/client/java/nova/client/client/module/ModuleManager.java

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void initialize() {
        register(new Module("Auto Sprint", "Sprint automatically while moving forward", Category.MOVEMENT) {
            @Override public void onTick() {
                Minecraft mc = Minecraft.getInstance();
                if (mc.player != null && mc.screen == null && mc.options.keyUp.isDown()
                        && !mc.player.isCrouching() && !mc.player.isUsingItem()) {
                    mc.player.setSprinting(true);
                }
            }
        });
        register(new Module("Player ESP", "Highlight loaded players", Category.RENDER) {
            @Override public void onTick() { glow(true, false, true); }
            @Override public void onDisable() { glow(true, false, false); }
        });
        register(new Module("Mob ESP", "Highlight loaded living mobs", Category.RENDER) {
            @Override public void onTick() { glow(false, true, true); }
            @Override public void onDisable() { glow(false, true, false); }
        });
        register(new Module("Macro Recorder", "Use F6 record, F7 replay, F8 stop", Category.MISC) {});
    }

    private void glow(boolean players, boolean mobs, boolean enabled) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity == mc.player) continue;
            boolean isPlayer = entity instanceof Player;
            if ((players && isPlayer) || (mobs && entity instanceof LivingEntity && !isPlayer)) {
                entity.setGlowingTag(enabled);
            }
        }
    }

    public void register(Module module) { modules.add(module); }
    public List<Module> getModules() { return Collections.unmodifiableList(modules); }
    public List<Module> getByCategory(Category category) {
        return modules.stream().filter(m -> m.getCategory() == category).toList();
    }
    public Module getByName(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }
    public void tick() {
        for (Module module : modules) if (module.isEnabled()) module.onTick();
    }
}
