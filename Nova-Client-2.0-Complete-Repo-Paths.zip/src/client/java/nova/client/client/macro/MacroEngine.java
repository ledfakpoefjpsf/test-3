package nova.client.client.macro;

// @name: MacroEngine
// @type: Client Input Recorder and Playback
// @location: src/client/java/nova/client/client/macro/MacroEngine.java

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public final class MacroEngine {
    private static final int[] KEYS = {
        GLFW.GLFW_KEY_W, GLFW.GLFW_KEY_A, GLFW.GLFW_KEY_S, GLFW.GLFW_KEY_D,
        GLFW.GLFW_KEY_SPACE, GLFW.GLFW_KEY_LEFT_SHIFT, GLFW.GLFW_KEY_LEFT_CONTROL,
        GLFW.GLFW_KEY_E, GLFW.GLFW_KEY_Q,
        GLFW.GLFW_KEY_1, GLFW.GLFW_KEY_2, GLFW.GLFW_KEY_3,
        GLFW.GLFW_KEY_4, GLFW.GLFW_KEY_5, GLFW.GLFW_KEY_6,
        GLFW.GLFW_KEY_7, GLFW.GLFW_KEY_8, GLFW.GLFW_KEY_9
    };
    private record Frame(long time, boolean[] keys, boolean left, boolean right) {}
    private static final List<Frame> frames = new ArrayList<>();
    private static boolean recording, playing, oldF6, oldF7, oldF8;
    private static long start, playStart;
    private static int next;

    private MacroEngine() {}

    public static void tick(Minecraft mc) {
        if (mc.getWindow() == null) return;
        long window = mc.getWindow().handle();
        boolean f6 = down(window, GLFW.GLFW_KEY_F6);
        boolean f7 = down(window, GLFW.GLFW_KEY_F7);
        boolean f8 = down(window, GLFW.GLFW_KEY_F8);
        if (f8 && !oldF8) stop(mc);
        if (mc.player != null && mc.screen == null) {
            if (f6 && !oldF6) {
                stop(mc);
                frames.clear();
                recording = true;
                start = System.nanoTime();
                System.out.println("[Nova Macro] Recording started");
            } else if (f7 && !oldF7 && !frames.isEmpty()) {
                stop(mc);
                playing = true;
                playStart = System.nanoTime();
                next = 0;
                System.out.println("[Nova Macro] Playback started: " + frames.size() + " frames");
            }
            if (recording) {
                boolean[] keys = new boolean[KEYS.length];
                for (int i = 0; i < KEYS.length; i++) keys[i] = down(window, KEYS[i]);
                frames.add(new Frame(System.nanoTime() - start, keys,
                    GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS,
                    GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS));
                if (frames.size() >= 18000) stop(mc); // 15 minutes at 20 TPS
            }
            if (playing) {
                long elapsed = System.nanoTime() - playStart;
                while (next < frames.size() && frames.get(next).time <= elapsed) {
                    apply(mc, frames.get(next++));
                }
                if (next >= frames.size()) stop(mc);
            }
        } else if (recording || playing) {
            stop(mc);
        }
        oldF6 = f6; oldF7 = f7; oldF8 = f8;
    }

    private static boolean down(long window, int key) {
        return GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
    }
    private static void apply(Minecraft mc, Frame frame) {
        KeyMapping[] mapped = {
            mc.options.keyUp, mc.options.keyLeft, mc.options.keyDown, mc.options.keyRight,
            mc.options.keyJump, mc.options.keyShift, mc.options.keySprint,
            mc.options.keyInventory, mc.options.keyDrop,
            mc.options.keyHotbarSlots[0], mc.options.keyHotbarSlots[1], mc.options.keyHotbarSlots[2],
            mc.options.keyHotbarSlots[3], mc.options.keyHotbarSlots[4], mc.options.keyHotbarSlots[5],
            mc.options.keyHotbarSlots[6], mc.options.keyHotbarSlots[7], mc.options.keyHotbarSlots[8]
        };
        for (int i = 0; i < mapped.length; i++) mapped[i].setDown(frame.keys[i]);
        mc.options.keyAttack.setDown(frame.left);
        mc.options.keyUse.setDown(frame.right);
    }
    public static void stop(Minecraft mc) {
        if (recording) System.out.println("[Nova Macro] Saved " + frames.size() + " frames");
        if (playing) {
            mc.options.keyAttack.setDown(false);
            mc.options.keyUse.setDown(false);
            mc.options.keyUp.setDown(false);
            mc.options.keyLeft.setDown(false);
            mc.options.keyDown.setDown(false);
            mc.options.keyRight.setDown(false);
            mc.options.keyJump.setDown(false);
            mc.options.keyShift.setDown(false);
            mc.options.keySprint.setDown(false);
            System.out.println("[Nova Macro] Playback stopped");
        }
        recording = false; playing = false;
    }
}
